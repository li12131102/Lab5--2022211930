
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { GMerchantE508Entity } from './gmerchante508entity';

@NgEntity({
    originalCode: "GCompany",
    nodeCode: "gCompanys"
})
export class GCompanyEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'Name',
        dataField: 'name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    name: string;

    @NgField({
        originalDataField: 'Address',
        dataField: 'address',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Address',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    address: string;

    @NgField({
        originalDataField: 'OS',
        dataField: 'os',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'on',
        path: 'OS',
    })
    os: any;

    @NgField({
        originalDataField: 'URL',
        dataField: 'url',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'URL',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    url: string;

    @NgObject({
        dataField: 'lr',
        originalDataField: 'LR',
        type: GMerchantE508Entity
    })
    lr: GMerchantE508Entity;
}