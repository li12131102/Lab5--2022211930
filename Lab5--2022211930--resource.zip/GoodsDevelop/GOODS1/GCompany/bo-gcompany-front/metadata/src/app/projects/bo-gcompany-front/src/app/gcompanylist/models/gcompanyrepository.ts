
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { GCompanyEntity } from './entities/gcompanyentity';

import { GCompanyProxy } from './gcompanyproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/goodsdevelop/goods1/v1.0/gcompanylist_frm',
    entityType: GCompanyEntity
})
export class GCompanyRepository extends BefRepository<GCompanyEntity> {
    public name = 'GCompanyRepository';

    public proxy: GCompanyProxy;
    public paginationInfo = {
        GCompanyEntity: {
            pageSize: 20,
        }
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(GCompanyProxy, null);
    }
}