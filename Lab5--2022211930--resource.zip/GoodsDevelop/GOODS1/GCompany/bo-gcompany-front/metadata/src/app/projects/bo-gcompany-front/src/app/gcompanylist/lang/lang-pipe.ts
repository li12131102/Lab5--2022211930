
import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer} from '@angular/platform-browser';
import { BasePathService } from '@farris/rtf';
export function createTranslateLoader(http: HttpClient,version:string) {
  let versionSuffix = "";
  if (version) {
    versionSuffix = "?v=" + version;
  }
  return new TranslateHttpLoader(http, BasePathService.convertPath('/apps/goodsdevelop/goods1/web/bo-gcompany-front/gcompanylist/i18n/'), '.json'+ versionSuffix);
}

export let lang = {"zh-CHS":{"QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1/control/enumValues/oni":"上市","QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1/control/enumValues/offi":"未上市","GridField/os_2c04eb08_bbtq/enumData/oni":"上市","GridField/os_2c04eb08_bbtq/enumData/offi":"未上市","root-component":"","root-layout":"","query-scheme-section":"","Section/query-scheme-section/mainTitle":"主标题","Section/query-scheme-section/subTitle":"","query-scheme-1":"默认筛选方案","QueryScheme/query-scheme-1/filterText":"筛选","QueryScheme/query-scheme-1/a9f4dede-13a4-47d9-bb3e-3295221ae50f":"主键","QueryScheme/query-scheme-1/a9f4dede-13a4-47d9-bb3e-3295221ae50f/placeHolder":"","QueryScheme/query-scheme-1/66557ea1-3bf6-484d-a054-479173cb7ffd":"版本","QueryScheme/query-scheme-1/66557ea1-3bf6-484d-a054-479173cb7ffd/placeHolder":"","QueryScheme/query-scheme-1/4890469b-c331-46fb-94e9-e7e4771efe3d":"名称","QueryScheme/query-scheme-1/4890469b-c331-46fb-94e9-e7e4771efe3d/placeHolder":"","QueryScheme/query-scheme-1/54b0b1ae-bf15-4f60-b4ca-303c7a5cc9a5":"地址","QueryScheme/query-scheme-1/54b0b1ae-bf15-4f60-b4ca-303c7a5cc9a5/placeHolder":"","QueryScheme/query-scheme-1/e5087038-94c5-4ce0-a867-d751c00885ce":"法人代表","QueryScheme/query-scheme-1/e5087038-94c5-4ce0-a867-d751c00885ce/placeHolder":"","QueryScheme/query-scheme-1/fda2a504-aff7-4203-8333-1e870e5e8de8":"主键","QueryScheme/query-scheme-1/fda2a504-aff7-4203-8333-1e870e5e8de8/placeHolder":"","QueryScheme/query-scheme-1/fedc3f64-2c76-4000-bf0e-85db76d1b572":"姓名","QueryScheme/query-scheme-1/fedc3f64-2c76-4000-bf0e-85db76d1b572/placeHolder":"","QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1":"营业状态","QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1/placeHolder":"","QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1/control/enumValues/on":"上市","QueryScheme/query-scheme-1/2c04eb08-f50d-41f9-9de0-d60e5d2cc1d1/control/enumValues/off":"未上市","QueryScheme/query-scheme-1/a03419ae-887d-4d54-9fd6-b83e7959bc37":"网站","QueryScheme/query-scheme-1/a03419ae-887d-4d54-9fd6-b83e7959bc37/placeHolder":"","page-header":"","header-nav":"","header-title-container":"","page-header-title":"","title":"公司总览","page-header-toolbar":"","button-add":"新增","button-edit":"编辑","button-view":"查看","button-delete":"删除","page-main":"","data-grid-component-ref":"","data-grid-component":"","data-grid-section":"","Section/data-grid-section/mainTitle":"","Section/data-grid-section/subTitle":"","dataGrid":"","DataGrid/dataGrid/lineNumberTitle":"","DataGrid/dataGrid/OperateEditButton":"编辑","DataGrid/dataGrid/OperateDeleteButton":"删除","DataGrid/dataGrid/OperateColumn":"操作","name_4890469b_5ad7":"公司名称","address_54b0b1ae_p7aj":"注册地址","lR_LR_Name_fedc3f64_3hz2":"控股人","os_2c04eb08_bbtq":"是否上市","GridField/os_2c04eb08_bbtq/enumData/on":"上市","GridField/os_2c04eb08_bbtq/enumData/off":"未上市","url_a03419ae_h9o0":"人员规模"}};

@Pipe({ name: 'lang' })
export class LangPipe implements PipeTransform {
  constructor(private translate: TranslateService, private http: HttpClient) { }
  transform(key: string, langCode: string, defaultValue?: string) {
      
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }
}
@Pipe({ name: 'safeHtml' })
export class SafeHtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    if (!url) {
      url = "";
    }
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
@Injectable()
export class LangService {
  constructor(private translate: TranslateService) { }
  transform(key: string, langCode: string, defaultValue?: string) {
    
    const translateValue = this.translate.instant(key);
    if (translateValue == "JitI18nDefaultValue") {
      return defaultValue ? defaultValue : "";
    }

    return translateValue;
  }

  getCurrentLanguage() {
    return this.translate.currentLang;
  }

}

@Injectable()
export class TranslateResolveService implements Resolve<any>{

  constructor(private translate: TranslateService, private http: HttpClient) {
    translate.defaultLang = 'zh-CHS';
    translate.setTranslation('zh-CHS', lang['zh-CHS']);
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    let langCode = localStorage.getItem('languageCode');
    if (!langCode) {
      langCode = "zh-CHS";
    }
    if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http,null))) {
      this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
      return of(this.translate[langCode]);
    } else {
      const httpOb = this.http.get(BasePathService.getBasePath() + "/apps/goodsdevelop/goods1/web/bo-gcompany-front/version.json?v=" + new Date().getTime()).pipe(switchMap((data)=>{
        let currentVersion = null;
        if (data instanceof Array) {
          const versionKey = "gcompanylist/" + langCode + ".json";
          data.forEach((item) => {
            if (item.category == "i18n" && item.key == versionKey) {
              currentVersion = item.value;
            }
          });
        }

        this.translate.defaultLang = langCode;
        this.translate.currentLang = langCode;
        this.translate.currentLoader = createTranslateLoader(this.http, currentVersion);

    let tran = this.translate.getTranslation(langCode).pipe(catchError(err => {
      console.error("read resource file failed,please check!!! "+ err);
      return of(err);
    }));
    return tran;
      }));
      return httpOb;
    }
  }
}
