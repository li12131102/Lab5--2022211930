import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_4890469b_5ad7}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '公司名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'address',
            name: "{{address_54b0b1ae_p7aj}}",
            binding: 'address',
            updateOn: 'blur',
            defaultI18nValue: '注册地址',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "address", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'lr.lR_Name',
            name: "{{lR_LR_Name_fedc3f64_3hz2}}",
            binding: 'lr.lR_Name',
            updateOn: 'blur',
            defaultI18nValue: '控股人',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "lR_LR_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'os',
            name: "{{os_2c04eb08_bbtq}}",
            binding: 'os',
            updateOn: 'change',
            defaultI18nValue: '是否上市',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "os", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'url',
            name: "{{url_a03419ae_h9o0}}",
            binding: 'url',
            updateOn: 'blur',
            defaultI18nValue: '人员规模',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "url", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '公司',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
