import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { GCompanyEntity } from './entities/gcompanyentity';
import { GCompanyProxy } from './gcompanyproxy';
var GCompanyRepository = /** @class */ (function (_super) {
    tslib_1.__extends(GCompanyRepository, _super);
    function GCompanyRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'GCompanyRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(GCompanyProxy, null);
        return _this;
    }
    GCompanyRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/goodsdevelop/goods1/v1.0/gcompanydlist_frm',
            entityType: GCompanyEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], GCompanyRepository);
    return GCompanyRepository;
}(BefRepository));
export { GCompanyRepository };
