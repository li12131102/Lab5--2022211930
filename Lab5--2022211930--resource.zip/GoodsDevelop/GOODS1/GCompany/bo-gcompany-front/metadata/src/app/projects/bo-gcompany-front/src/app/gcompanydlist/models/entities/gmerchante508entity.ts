
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "LR",
    nodeCode: "lr"
})
export class GMerchantE508Entity extends Entity {

    @NgField({
        originalDataField: 'LR',
        dataField: 'lr',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'LR.LR',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    lr: string;

    @NgField({
        originalDataField: 'ID',
        dataField: 'lR_ID',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'LR.LR_ID',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    lR_ID: string;

    @NgField({
        originalDataField: 'Name',
        dataField: 'lR_Name',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'LR.LR_Name',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    lR_Name: string;

}