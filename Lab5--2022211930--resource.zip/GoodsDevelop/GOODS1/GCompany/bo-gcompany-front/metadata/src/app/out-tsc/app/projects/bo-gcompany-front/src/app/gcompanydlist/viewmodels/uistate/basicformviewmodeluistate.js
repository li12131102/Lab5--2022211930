import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState, NgParam } from '@farris/devkit';
var BasicFormViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelUIState, _super);
    function BasicFormViewmodelUIState() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.lRLRNameBindDataSource = [];
        return _this;
    }
    tslib_1.__decorate([
        NgParam({ originalDataType: "Array", category: "locale" }),
        tslib_1.__metadata("design:type", Array)
    ], BasicFormViewmodelUIState.prototype, "lRLRNameBindDataSource", void 0);
    BasicFormViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], BasicFormViewmodelUIState);
    return BasicFormViewmodelUIState;
}(UIState));
export { BasicFormViewmodelUIState };
