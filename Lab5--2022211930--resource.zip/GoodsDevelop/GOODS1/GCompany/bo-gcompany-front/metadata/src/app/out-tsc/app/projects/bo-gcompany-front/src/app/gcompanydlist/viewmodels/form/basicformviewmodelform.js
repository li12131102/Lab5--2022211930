import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_df9742c1_htdq',
            name: "{{name_df9742c1_htdq}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'address_09ac33d2_3y7l',
            name: "{{address_09ac33d2_3y7l}}",
            binding: 'address',
            updateOn: 'blur',
            defaultI18nValue: '注册地址',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "address", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'lR_LR_Name_e23ccff7_10t4',
            name: "{{lR_LR_Name_e23ccff7_10t4}}",
            binding: 'lr.lR_Name',
            updateOn: 'blur',
            defaultI18nValue: '控股人',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "lR_LR_Name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'url_ad58a1bd_7r1j',
            name: "{{url_ad58a1bd_7r1j}}",
            binding: 'url',
            updateOn: 'blur',
            defaultI18nValue: '人数规模',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "url", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'os_f4017a55_zk7a',
            name: "{{os_f4017a55_zk7a}}",
            binding: 'os',
            updateOn: 'change',
            defaultI18nValue: '营业状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "os", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '公司',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
