import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { GMerchantE508Entity } from './gmerchante508entity';
var GCompanyEntity = /** @class */ (function (_super) {
    tslib_1.__extends(GCompanyEntity, _super);
    function GCompanyEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GCompanyEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], GCompanyEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GCompanyEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Address',
            dataField: 'address',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Address',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GCompanyEntity.prototype, "address", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'OS',
            dataField: 'os',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'on',
            path: 'OS',
        }),
        tslib_1.__metadata("design:type", Object)
    ], GCompanyEntity.prototype, "os", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'URL',
            dataField: 'url',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'URL',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GCompanyEntity.prototype, "url", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'lr',
            originalDataField: 'LR',
            type: GMerchantE508Entity
        }),
        tslib_1.__metadata("design:type", GMerchantE508Entity)
    ], GCompanyEntity.prototype, "lr", void 0);
    GCompanyEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "GCompany",
            nodeCode: "gCompanys"
        })
    ], GCompanyEntity);
    return GCompanyEntity;
}(Entity));
export { GCompanyEntity };
