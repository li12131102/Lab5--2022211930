
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '公司',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'name',
        name: "{{name_4890469b_5ad7}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '公司名称',
    })
    name: FormControl;

    @NgFormControl({
        id: 'address',
        name: "{{address_54b0b1ae_p7aj}}",
        binding: 'address',
        updateOn: 'blur',
        defaultI18nValue: '注册地址',
    })
    address: FormControl;

    @NgFormControl({
        id: 'lr.lR_Name',
        name: "{{lR_LR_Name_fedc3f64_3hz2}}",
        binding: 'lr.lR_Name',
        updateOn: 'blur',
        defaultI18nValue: '控股人',
    })
    lR_LR_Name: FormControl;

    @NgFormControl({
        id: 'os',
        name: "{{os_2c04eb08_bbtq}}",
        binding: 'os',
        updateOn: 'change',
        defaultI18nValue: '是否上市',
    })
    os: FormControl;

    @NgFormControl({
        id: 'url',
        name: "{{url_a03419ae_h9o0}}",
        binding: 'url',
        updateOn: 'blur',
        defaultI18nValue: '人员规模',
    })
    url: FormControl;

}