import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var GMerchantE508Entity = /** @class */ (function (_super) {
    tslib_1.__extends(GMerchantE508Entity, _super);
    function GMerchantE508Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'LR',
            dataField: 'lr',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'LR.LR',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GMerchantE508Entity.prototype, "lr", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'lR_ID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'LR.LR_ID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GMerchantE508Entity.prototype, "lR_ID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'lR_Name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'LR.LR_Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GMerchantE508Entity.prototype, "lR_Name", void 0);
    GMerchantE508Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "LR",
            nodeCode: "lr"
        })
    ], GMerchantE508Entity);
    return GMerchantE508Entity;
}(Entity));
export { GMerchantE508Entity };
