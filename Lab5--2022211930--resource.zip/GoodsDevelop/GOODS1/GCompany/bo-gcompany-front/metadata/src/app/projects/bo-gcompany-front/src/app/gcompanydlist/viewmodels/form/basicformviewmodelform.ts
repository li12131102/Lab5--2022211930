
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '公司',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'name_df9742c1_htdq',
        name: "{{name_df9742c1_htdq}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    name: FormControl;

    @NgFormControl({
        id: 'address_09ac33d2_3y7l',
        name: "{{address_09ac33d2_3y7l}}",
        binding: 'address',
        updateOn: 'blur',
        defaultI18nValue: '注册地址',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    address: FormControl;

    @NgFormControl({
        id: 'lR_LR_Name_e23ccff7_10t4',
        name: "{{lR_LR_Name_e23ccff7_10t4}}",
        binding: 'lr.lR_Name',
        updateOn: 'blur',
        defaultI18nValue: '控股人',
    })
    lR_LR_Name: FormControl;

    @NgFormControl({
        id: 'url_ad58a1bd_7r1j',
        name: "{{url_ad58a1bd_7r1j}}",
        binding: 'url',
        updateOn: 'blur',
        defaultI18nValue: '人数规模',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    url: FormControl;

    @NgFormControl({
        id: 'os_f4017a55_zk7a',
        name: "{{os_f4017a55_zk7a}}",
        binding: 'os',
        updateOn: 'change',
        defaultI18nValue: '营业状态',
    })
    os: FormControl;

}