import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
var routes = [
    { path: 'GOODDSSS12341', loadChildren: './gooddsss12341/gooddsss12341#GOODDSSS12341Module' },
    { path: 'GGGOODDSS987', loadChildren: './gggooddss987/gggooddss987#GGGOODDSS987Module' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib_1.__decorate([
        NgModule({
            imports: [RouterModule.forRoot(routes, { useHash: true })],
            exports: [RouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
export { AppRoutingModule };
