import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'goods.goods_GoodsName',
            name: "{{goods_Goods_GoodsName_5633b50f_fe7e}}",
            binding: 'goods.goods_GoodsName',
            updateOn: 'blur',
            defaultI18nValue: '商品名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "goods_Goods_GoodsName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'st',
            name: "{{st_8bcb3d94_m6ar}}",
            binding: 'st',
            updateOn: 'change',
            defaultI18nValue: '开发状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "st", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'price',
            name: "{{price_16f37a3a_7wz1}}",
            binding: 'price',
            updateOn: 'blur',
            defaultI18nValue: '目前开发人数',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "price", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'other',
            name: "{{other_7f77f6cc_sbr3}}",
            binding: 'other',
            updateOn: 'blur',
            defaultI18nValue: '（预计）完成时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "other", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '商品活动',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
