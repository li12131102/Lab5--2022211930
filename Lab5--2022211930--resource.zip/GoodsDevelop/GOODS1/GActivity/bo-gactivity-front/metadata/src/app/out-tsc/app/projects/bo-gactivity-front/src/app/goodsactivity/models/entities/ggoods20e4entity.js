import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var GGoods20e4Entity = /** @class */ (function (_super) {
    tslib_1.__extends(GGoods20e4Entity, _super);
    function GGoods20e4Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Goods',
            dataField: 'goods',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Goods.Goods',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GGoods20e4Entity.prototype, "goods", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'goods_ID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Goods.Goods_ID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GGoods20e4Entity.prototype, "goods_ID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'GoodsName',
            dataField: 'goods_GoodsName',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Goods.Goods_GoodsName',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GGoods20e4Entity.prototype, "goods_GoodsName", void 0);
    GGoods20e4Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Goods",
            nodeCode: "goods"
        })
    ], GGoods20e4Entity);
    return GGoods20e4Entity;
}(Entity));
export { GGoods20e4Entity };
