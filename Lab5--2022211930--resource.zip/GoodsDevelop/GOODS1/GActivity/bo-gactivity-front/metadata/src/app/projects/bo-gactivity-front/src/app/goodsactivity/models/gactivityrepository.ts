
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { GActivityEntity } from './entities/gactivityentity';

import { GActivityProxy } from './gactivityproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/goodsdevelop/goods1/v1.0/goodsactivity_frm',
    entityType: GActivityEntity
})
export class GActivityRepository extends BefRepository<GActivityEntity> {
    public name = 'GActivityRepository';

    public proxy: GActivityProxy;
    public paginationInfo = {
        GActivityEntity: {
            pageSize: 20,
        }
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(GActivityProxy, null);
    }
}