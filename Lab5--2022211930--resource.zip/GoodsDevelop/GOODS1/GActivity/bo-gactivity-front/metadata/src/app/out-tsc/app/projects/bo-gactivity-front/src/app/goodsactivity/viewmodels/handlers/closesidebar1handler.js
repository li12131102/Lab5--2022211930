import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SidebarService as SidebarService1 } from '@farris/command-services';
var CloseSidebar1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(CloseSidebar1Handler, _super);
    function CloseSidebar1Handler(_SidebarService1) {
        var _this = _super.call(this) || this;
        _this._SidebarService1 = _SidebarService1;
        return _this;
    }
    CloseSidebar1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('closeSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'closeSidebar', args, context);
        });
    };
    CloseSidebar1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'CloseSidebar1'
        }),
        tslib_1.__metadata("design:paramtypes", [SidebarService1])
    ], CloseSidebar1Handler);
    return CloseSidebar1Handler;
}(CommandHandler));
export { CloseSidebar1Handler };
