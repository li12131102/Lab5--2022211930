import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BefProxy, UriService } from '@farris/bef';
var GActivityProxy = /** @class */ (function (_super) {
    tslib_1.__extends(GActivityProxy, _super);
    function GActivityProxy(httpClient, uriService) {
        var _this = _super.call(this, httpClient, uriService) || this;
        _this.apiUrl = 'api/goodsdevelop/goods1/v1.0/goodsactivity_frm';
        _this.baseUri = uriService.extendUri(_this.apiUrl);
        return _this;
    }
    GActivityProxy = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [HttpClient,
            UriService])
    ], GActivityProxy);
    return GActivityProxy;
}(BefProxy));
export { GActivityProxy };
