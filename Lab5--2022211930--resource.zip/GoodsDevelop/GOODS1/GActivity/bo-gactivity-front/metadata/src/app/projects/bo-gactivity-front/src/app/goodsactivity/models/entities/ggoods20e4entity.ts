
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';

@NgEntity({
    originalCode: "Goods",
    nodeCode: "goods"
})
export class GGoods20e4Entity extends Entity {

    @NgField({
        originalDataField: 'Goods',
        dataField: 'goods',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Goods.Goods',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    goods: string;

    @NgField({
        originalDataField: 'ID',
        dataField: 'goods_ID',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Goods.Goods_ID',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    goods_ID: string;

    @NgField({
        originalDataField: 'GoodsName',
        dataField: 'goods_GoodsName',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Goods.Goods_GoodsName',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    goods_GoodsName: string;

}