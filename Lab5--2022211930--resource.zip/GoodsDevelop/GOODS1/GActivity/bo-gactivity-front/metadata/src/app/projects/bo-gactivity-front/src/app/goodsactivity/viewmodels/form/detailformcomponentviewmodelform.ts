
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '商品活动',
    enableValidate: true
})

@Injectable()
export class DetailFormComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'goods_Goods_GoodsName_5633b50f_4xbl',
        name: "{{goods_Goods_GoodsName_5633b50f_4xbl}}",
        binding: 'goods.goods_GoodsName',
        updateOn: 'blur',
        defaultI18nValue: '商品名称',
    })
    goods_Goods_GoodsName: FormControl;

    @NgFormControl({
        id: 'st_8bcb3d94_2jk2',
        name: "{{st_8bcb3d94_2jk2}}",
        binding: 'st',
        updateOn: 'change',
        defaultI18nValue: '开发状态',
        validRules: [
            {
                type: 'required',
                constraints: [true],
            }
        ]
    })
    st: FormControl;

    @NgFormControl({
        id: 'price_16f37a3a_f5xx',
        name: "{{price_16f37a3a_f5xx}}",
        binding: 'price',
        updateOn: 'blur',
        defaultI18nValue: '目前开发人数',
    })
    price: FormControl;

    @NgFormControl({
        id: 'other_7f77f6cc_deyj',
        name: "{{other_7f77f6cc_deyj}}",
        binding: 'other',
        updateOn: 'blur',
        defaultI18nValue: '（预计）开发完成时间',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    other: FormControl;

}