import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { GGoods20e4Entity } from './ggoods20e4entity';
var GActivityEntity = /** @class */ (function (_super) {
    tslib_1.__extends(GActivityEntity, _super);
    function GActivityEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GActivityEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], GActivityEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ST',
            dataField: 'st',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'on',
            path: 'ST',
        }),
        tslib_1.__metadata("design:type", Object)
    ], GActivityEntity.prototype, "st", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Price',
            dataField: 'price',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'Price',
        }),
        tslib_1.__metadata("design:type", Object)
    ], GActivityEntity.prototype, "price", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Other',
            dataField: 'other',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Other',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GActivityEntity.prototype, "other", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'goods',
            originalDataField: 'Goods',
            type: GGoods20e4Entity
        }),
        tslib_1.__metadata("design:type", GGoods20e4Entity)
    ], GActivityEntity.prototype, "goods", void 0);
    GActivityEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "GActivity",
            nodeCode: "gActivitys",
            allowEmpty: true
        })
    ], GActivityEntity);
    return GActivityEntity;
}(Entity));
export { GActivityEntity };
