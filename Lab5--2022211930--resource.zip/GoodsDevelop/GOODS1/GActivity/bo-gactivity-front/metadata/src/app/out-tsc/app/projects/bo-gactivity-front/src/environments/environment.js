export var environment = {
    production: true
};
