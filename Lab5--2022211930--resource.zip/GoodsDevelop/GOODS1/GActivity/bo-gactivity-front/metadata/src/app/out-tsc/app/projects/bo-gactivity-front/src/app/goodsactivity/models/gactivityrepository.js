import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { GActivityEntity } from './entities/gactivityentity';
import { GActivityProxy } from './gactivityproxy';
var GActivityRepository = /** @class */ (function (_super) {
    tslib_1.__extends(GActivityRepository, _super);
    function GActivityRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'GActivityRepository';
        _this.paginationInfo = {
            GActivityEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(GActivityProxy, null);
        return _this;
    }
    GActivityRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/goodsdevelop/goods1/v1.0/goodsactivity_frm',
            entityType: GActivityEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], GActivityRepository);
    return GActivityRepository;
}(BefRepository));
export { GActivityRepository };
