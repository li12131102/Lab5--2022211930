
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler, CommandContext } from '@farris/devkit';

import { SidebarService as SidebarService1 } from '@farris/command-services';
import { ValidationService as ValidationService1 } from '@farris/command-services';
import { ListDataService as ListDataService1 } from '@farris/command-services';
import { CardDataService as CardDataService1 } from '@farris/command-services';
import { StateMachineService as StateMachineService1 } from '@farris/command-services';

@Injectable()
@NgCommandHandler({
    commandName: 'CheckBeforeClosingSidebar1'
})
export class CheckBeforeClosingSidebar1Handler extends CommandHandler {
    constructor(
        public _SidebarService1: SidebarService1,
        public _ValidationService1: ValidationService1,
        public _ListDataService1: ListDataService1,
        public _CardDataService1: CardDataService1,
        public _StateMachineService1: StateMachineService1
    ) {
        super();
    }

    schedule() {
        this.addTask('confirmBeforeClosingSidebar', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._SidebarService1, 'confirmBeforeClosingSidebar', args, context);
        });

        this.addTask('cancelWithoutCheck', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._CardDataService1, 'cancelWithoutCheck', args, context);
        });

        this.addTask('load', (context: CommandContext) => {
            const args = [
                '{COMMAND~/params/filter}', 
                '{COMMAND~/params/sort}'
                    ];
            return this.invoke(this._ListDataService1, 'load', args, context);
        });

        this.addTask('updateWithoutEmpty', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._CardDataService1, 'updateWithoutEmpty', args, context);
        });

        this.addTask('transit', (context: CommandContext) => {
            const args = [
                '{COMMAND~/params/transitionAction}'
                    ];
            return this.invoke(this._StateMachineService1, 'transit', args, context);
        });

        this.addTask('resetValidation', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._ValidationService1, 'resetValidation', args, context);
        });

        this.addTask('continueClosingSidebar', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._SidebarService1, 'continueClosingSidebar', args, context);
        });

        this.addTask('stopClosingSidebar', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._SidebarService1, 'stopClosingSidebar', args, context);
        });

        this.addLink('confirmBeforeClosingSidebar', 'cancelWithoutCheck', `'{COMMAND~/results/confirmBeforeClosingSidebar}'==='true'`);
        this.addLink('confirmBeforeClosingSidebar', 'stopClosingSidebar', `'{COMMAND~/results/confirmBeforeClosingSidebar}'==='false'`);
        this.addLink('cancelWithoutCheck', 'load', `1==1`);
        this.addLink('load', 'updateWithoutEmpty', `1==1`);
        this.addLink('updateWithoutEmpty', 'transit', `1==1`);
        this.addLink('transit', 'resetValidation', `1==1`);
        this.addLink('resetValidation', 'continueClosingSidebar', `1==1`);
    }
}