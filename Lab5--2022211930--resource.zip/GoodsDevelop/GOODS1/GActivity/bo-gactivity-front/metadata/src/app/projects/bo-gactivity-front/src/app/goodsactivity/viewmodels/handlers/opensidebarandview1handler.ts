
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler, CommandContext } from '@farris/devkit';

import { SidebarService as SidebarService1 } from '@farris/command-services';

@Injectable()
@NgCommandHandler({
    commandName: 'OpenSidebarAndView1'
})
export class OpenSidebarAndView1Handler extends CommandHandler {
    constructor(
        public _SidebarService1: SidebarService1
    ) {
        super();
    }

    schedule() {
        this.addTask('openSidebar', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._SidebarService1, 'openSidebar', args, context);
        });

    }
}