import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState, NgParam } from '@farris/devkit';
var DetailFormComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelUIState, _super);
    function DetailFormComponentViewmodelUIState() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.stBindDataSource = [];
        return _this;
    }
    tslib_1.__decorate([
        NgParam({ originalDataType: "Array", category: "locale" }),
        tslib_1.__metadata("design:type", Array)
    ], DetailFormComponentViewmodelUIState.prototype, "stBindDataSource", void 0);
    DetailFormComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], DetailFormComponentViewmodelUIState);
    return DetailFormComponentViewmodelUIState;
}(UIState));
export { DetailFormComponentViewmodelUIState };
