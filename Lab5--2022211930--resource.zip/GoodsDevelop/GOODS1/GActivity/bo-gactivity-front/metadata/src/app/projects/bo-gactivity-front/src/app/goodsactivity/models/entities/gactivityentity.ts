
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { GGoods20e4Entity } from './ggoods20e4entity';

@NgEntity({
    originalCode: "GActivity",
    nodeCode: "gActivitys",
    allowEmpty: true
})
export class GActivityEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'ST',
        dataField: 'st',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'on',
        path: 'ST',
    })
    st: any;

    @NgField({
        originalDataField: 'Price',
        dataField: 'price',
        originalDataFieldType: 'Number',
        initValue: 0,
        path: 'Price',
    })
    price: any;

    @NgField({
        originalDataField: 'Other',
        dataField: 'other',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Other',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    other: string;

    @NgObject({
        dataField: 'goods',
        originalDataField: 'Goods',
        type: GGoods20e4Entity
    })
    goods: GGoods20e4Entity;
}