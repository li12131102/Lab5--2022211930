
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler, CommandContext } from '@farris/devkit';

import { SidebarService as SidebarService1 } from '@farris/command-services';
import { CardDataService as CardDataService1 } from '@farris/command-services';
import { StateMachineService as StateMachineService1 } from '@farris/command-services';

@Injectable()
@NgCommandHandler({
    commandName: 'OpenSidebarAndEdit1'
})
export class OpenSidebarAndEdit1Handler extends CommandHandler {
    constructor(
        public _SidebarService1: SidebarService1,
        public _CardDataService1: CardDataService1,
        public _StateMachineService1: StateMachineService1
    ) {
        super();
    }

    schedule() {
        this.addTask('openSidebar', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._SidebarService1, 'openSidebar', args, context);
        });

        this.addTask('update', (context: CommandContext) => {
            const args = [];
            return this.invoke(this._CardDataService1, 'update', args, context);
        });

        this.addTask('transit', (context: CommandContext) => {
            const args = [
                '{COMMAND~/params/transitionAction}'
                    ];
            return this.invoke(this._StateMachineService1, 'transit', args, context);
        });

        this.addLink('openSidebar', 'update', `1==1`);
        this.addLink('update', 'transit', `1==1`);
    }
}