
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';

import { DataGridComponentViewmodel } from './datagridcomponentviewmodel';

import { DetailFormComponentViewmodel } from './detailformcomponentviewmodel';

@Injectable()
export class RootViewmodel extends ViewModel {
    public bindingPath = '/';
    public dom = {};
    public childViewModels = {
        'DataGridComponentViewmodel' : 'dataGridComponentViewmodel',
        'DetailFormComponentViewmodel' : 'detailFormComponentViewmodel'
    }
    public dataGridComponentViewmodel: DataGridComponentViewmodel;
    public detailFormComponentViewmodel: DetailFormComponentViewmodel;
    @NgCommand({
        name: 'LoadList1',
        params: {
            filter: '',
            sort: ''
        },
        paramDescriptions: {
            filter: { type: 'string' },
            sort: { type: 'string' }
        }
    })
    public LoadList1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'OpenSidebarAndAdd1',
        params: {
            transitionAction: 'Create'
        },
        paramDescriptions: {
            transitionAction: { type: 'string' }
        }
    })
    public OpenSidebarAndAdd1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'OpenSidebarAndEdit1',
        params: {
            transitionAction: 'Edit'
        },
        paramDescriptions: {
            transitionAction: { type: 'string' }
        }
    })
    public OpenSidebarAndEdit1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'OpenSidebarAndView1',
        params: {
        }
    })
    public OpenSidebarAndView1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'Remove1',
        params: {
            currentId: '{DATA~/#{data-grid-component}/id}',
            refreshCommandName: '',
            refreshCommandFrameId: '',
            ifSave: '',
            successMsg: ''
        },
        paramDescriptions: {
            currentId: { type: 'string' },
            refreshCommandName: { type: '' },
            refreshCommandFrameId: { type: '' },
            ifSave: { type: '' },
            successMsg: { type: '' }
        }
    })
    public Remove1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'Add1',
        params: {
            transitState: 'Create'
        },
        paramDescriptions: {
            transitState: { type: 'string' }
        }
    })
    public Add1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'Edit1',
        params: {
            transitState: 'Edit'
        },
        paramDescriptions: {
            transitState: { type: 'string' }
        }
    })
    public Edit1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'Save1',
        params: {
            transitState: 'Save',
            successMsg: ''
        },
        paramDescriptions: {
            transitState: { type: 'string' },
            successMsg: { type: '' }
        }
    })
    public Save1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'Cancel1',
        params: {
            transitState: 'Cancel',
            loadCmdName: '',
            loadCmdFrameId: ''
        },
        paramDescriptions: {
            transitState: { type: 'string' },
            loadCmdName: { type: 'string' },
            loadCmdFrameId: { type: 'string' }
        }
    })
    public Cancel1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'AddItem1',
        params: {
        }
    })
    public AddItem1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'RemoveItem1',
        params: {
            id: '',
            successMsg: ''
        },
        paramDescriptions: {
            id: { type: 'string' },
            successMsg: { type: '' }
        }
    })
    public RemoveItem1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'CheckBeforeClosingSidebar1',
        params: {
            transitionAction: 'Cancel',
            filter: '',
            sort: ''
        },
        paramDescriptions: {
            transitionAction: { type: 'string' },
            filter: { type: 'string' },
            sort: { type: 'string' }
        }
    })
    public CheckBeforeClosingSidebar1(commandParam?: any): Observable<any> { return; }

    @NgCommand({
        name: 'CloseSidebar1',
        params: {
        }
    })
    public CloseSidebar1(commandParam?: any): Observable<any> { return; }

}