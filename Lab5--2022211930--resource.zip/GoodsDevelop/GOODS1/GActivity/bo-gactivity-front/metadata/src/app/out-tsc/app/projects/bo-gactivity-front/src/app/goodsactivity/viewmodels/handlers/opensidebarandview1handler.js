import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SidebarService as SidebarService1 } from '@farris/command-services';
var OpenSidebarAndView1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(OpenSidebarAndView1Handler, _super);
    function OpenSidebarAndView1Handler(_SidebarService1) {
        var _this = _super.call(this) || this;
        _this._SidebarService1 = _SidebarService1;
        return _this;
    }
    OpenSidebarAndView1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('openSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'openSidebar', args, context);
        });
    };
    OpenSidebarAndView1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'OpenSidebarAndView1'
        }),
        tslib_1.__metadata("design:paramtypes", [SidebarService1])
    ], OpenSidebarAndView1Handler);
    return OpenSidebarAndView1Handler;
}(CommandHandler));
export { OpenSidebarAndView1Handler };
